import { Context, Schema } from 'koishi';
export declare function parsePlatform(target: string): [platform: string, id: string];
export interface Config {
}
export declare const name = "echo";
export declare const Config: Schema<Config>;
export declare function apply(ctx: Context, config: Config): void;
